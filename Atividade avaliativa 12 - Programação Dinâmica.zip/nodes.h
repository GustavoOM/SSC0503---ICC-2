#ifndef NODES_H
#define NODES_H


typedef struct NODE_ NODE;

struct NODE_{
    int origem;
    int destino;
    int amigos;
}; //


#endif  // NODES_H