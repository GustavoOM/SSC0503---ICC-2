#ifndef OPERATIONS_H
#define OPERATIONS_H


#include"nodes.h"

int encontrarMelhorCaminho_(NODE *ruas, int quantidadeDeRuas, int origem, int destino, int linhas, int colunas);
int encontrarMelhorCaminho(NODE *ruas, int quantidadeDeRuas, int linhas, int colunas);
#endif //OPERATIONS_H