#include <stdio.h>
#include <stdlib.h>
#include "merge.h"

void _merge2Vetor(int *vetor, int inicio1, int fim1, int inicio2, int fim2, int *tmp, int *comparacao, int *troca)
{
    int i1 = inicio1;
    int i2 = inicio2;
    int j = 0;
    while (i1 <= fim1 && i2 <= fim2)
    {
        *comparacao = *comparacao + 1;
        *troca = *troca + 1;
        if(vetor[i1] <= vetor[i2])
        {
            tmp[j] = vetor[i1];
            j++;
            i1++;
        }
        else
        {
            tmp[j] = vetor[i2];
            j++;
            i2++;
        }
        
    }

    while(i1 <= fim1)
    {
        *troca = *troca + 1;
        tmp[j] = vetor[i1];
        j++;
        i1++;
    }

    while(i2 <= fim2)
    {
        *troca = *troca + 1;
        tmp[j] = vetor[i2];
        j++;
        i2++;
    }

    j = 0;
    for (int i = inicio1; i <= fim2; i++, j++)
    {
        *troca = *troca + 1;
        vetor[i] = tmp[j];
    }
}
void _merge(int *vetor, int inicio, int fim, int *tmp, int *comparacao, int *troca)
{
    if(inicio >= fim)
    {
        return;
    }
    int meio = (inicio + fim)/2;
    _merge(vetor, inicio, meio, tmp, comparacao, troca);
    _merge(vetor, meio + 1, fim, tmp, comparacao, troca);
    _merge2Vetor(vetor, inicio, meio, meio + 1, fim, tmp, comparacao, troca);
}
void merge(int *vetor, int n)
{
    int *tmp = (int *) malloc(n*sizeof(int));
    if(tmp == NULL)
    {
        exit(-1);
    }

    int troca = 0;
    int comparacao = 0;
    _merge(vetor, 0, n - 1, tmp, &comparacao, &troca);
    printf("M %d %d %d\n", n, troca, comparacao);
    free(tmp);
}