#ifndef INSERTION_H
#define INSERTION_H
void insertion(int *vetor, int n);
#endif