#include <stdio.h>
#include "insertion.h"

void insertion(int *vetor, int n)
{
    int troca = 0;
    int comparacao = 0;
    int x;

    for (int i = 1; i < n; i++)
    {
        int j = i - 1;
        troca++;
        x = vetor[i];
        while(j >= 0)
        {
            comparacao++;
            if(vetor[j] > x)
            {
                troca++;
                vetor[j + 1] = vetor[j];
                j--;
            }
            else
            {
                break;
            }
        }
        troca++;
        vetor[j + 1] = x;
    }
    printf("I %d %d %d\n", n, troca, comparacao);
}