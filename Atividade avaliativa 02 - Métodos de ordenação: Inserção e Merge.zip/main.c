#include <stdio.h>
#include <stdlib.h>
#include "insertion.h"
#include "merge.h"

int main()
{
    int q; // Quantidade de vetores lidos
    int *n; // Tamanho de cada vetor
    int **vetores; //lista de vetores

    //Leitura dos dados
    scanf("%d", &q);
    n = (int *) malloc(q*sizeof(int));
    if(n == NULL)
    {
        return -1;
    }
    vetores = (int **) malloc(q*sizeof(int *));
    if(vetores == NULL)
    {
        return -1;
    }
    for(int i = 0; i < q; i++)
    {
        scanf("%d", &n[i]);
        vetores[i] = (int *) malloc(n[i]*sizeof(int));
        if(vetores[i] == NULL)
        {
            return -1;
        }
    }
    for(int i = 0; i < q; i++)
    {
        for(int j = 0; j < n[i]; j++)
        {
            scanf("%d", &vetores[i][j]);
        }
    } 


    //Algoritmo de ordenação
    for(int i = 0; i < q; i++)
    {
        //cria uma cópia do vetor a ser ordenado para ser usado no merge, pois o insertion ordena o vetor original
        int *vetorMerge = (int *) malloc(n[i]*sizeof(int));
        for(int j = 0; j < n[i]; j++)
        {
            vetorMerge[j] = vetores[i][j];
        }

        insertion(vetores[i], n[i]);
        merge(vetorMerge, n[i]);

        free(vetorMerge);
    }

    //Liberar os mallocs
    free(n);
    for(int i = 0; i < q; i++)
    {
        free(vetores[i]);
    }
    free(vetores);
}