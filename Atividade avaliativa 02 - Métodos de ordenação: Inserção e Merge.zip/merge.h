#ifndef MERGE_H
#define MERGE_H
void merge(int *vetor, int n);
#endif