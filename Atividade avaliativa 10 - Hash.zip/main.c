#include "Hash.h"

int main() 
{  
    int capacidadeTabela = 0;
    int totalInsercoes = 0;
    int numero;  
    if(!scanf("%d", &capacidadeTabela))
    {
        return ERRO;
    }
    //N -> Total de inserções
    if(!scanf("%d", &totalInsercoes))
    {
        return ERRO;
    }  
    NUMERO *tabela = NULL;
    tabela = tabela_criar(capacidadeTabela);
    tabela = tabela_zerar(tabela, capacidadeTabela);
    for(int i = 0; i < totalInsercoes; i++)
    {
        //ler e inserir os numeros na tabela
        if(!scanf("%d", &numero))
        {
            return ERRO;
        }
        inserirNaTabela(numero, capacidadeTabela, tabela);
    }
    //imprimirTabela(tabela, capacidadeTabela);
    //D -> total de remocoes
    int totalDeRemocoes = 0;
    if(!scanf("%d", &totalDeRemocoes))
    {
        return ERRO;
    }
    int chaveRemocao;
    for(int i = 0; i < totalDeRemocoes; i++)
    {
      //buscar e imprimir index de onde está o elemento na tabela
      if(!scanf("%d", &chaveRemocao))
      {
          return ERRO;
      }
      deletarDaTabela(chaveRemocao, capacidadeTabela, tabela);
      //se nao for encontrado imprime lugar_vazio
    }

    //B -> total de buscas
    int totalDeBuscas = 0;
    if(!scanf("%d", &totalDeBuscas))
    {
        return ERRO;
    }
    int chaveDeBusca;
    for(int i = 0; i < totalDeBuscas; i++)
    {
        //buscar e imprimir index de onde está o elemento na tabela
        if(!scanf("%d", &chaveDeBusca))
        {
            return ERRO;
        }
        buscarNaTabela(chaveDeBusca, capacidadeTabela, tabela);
        //se nao for encontrado imprime lugar_vazio
    }
    tabela_apagar(&tabela);
    return 0;
}